# Optimization batch review

Retained incumbent: `326e352fa0a4e9aa5d6899a3ad631e8f47b0c07419fcba9dd649ccf9d1d413ee`.
Strongest verified candidate or retained incumbent: `326e352fa0a4e9aa5d6899a3ad631e8f47b0c07419fcba9dd649ccf9d1d413ee`.
Promotion: retain incumbent.

| Candidate | Selection | Fitness | Requested games | Candidate failure attempts | Reasons |
| --- | --- | --- | --- | --- | --- |
| 2c91b5a7b228 | advance | 1.0 | 4 | 0 | saved gates passed |
| 326e352fa0a4 | retain | 0.0 | 4 | 0 | saved gates passed |



Weak cell for 2c91b5a7b228: opponent as black, score 2.0/2; distinct evidence 2.

Weak cell for 2c91b5a7b228: opponent as white, score 2.0/2; distinct evidence 2.

Candidate turn time: p95 0.00636799813946709 ms, max 0.00636799813946709 ms (2 observations; 0 missing).

Weak cell for 326e352fa0a4: opponent as black, score 0.0/2; distinct evidence 2.

Weak cell for 326e352fa0a4: opponent as white, score 0.0/2; distinct evidence 2.

Candidate turn time: p95 0.012381999113131315 ms, max 0.012381999113131315 ms (2 observations; 0 missing).

Representative failures (categories and clock pressure are hypotheses):

- 326e352fa0a4 vs opponent, color 1, plies [], low clock False; trace `e4c145a0a066b10a0c383eccc38c89a56bc1379049c3f792728e41845794a316`.
- 326e352fa0a4 vs opponent, color 0, plies [0], low clock False; trace `5cecb24101694d82d3f79e4c0f70f25204d481fd993b49c2840a805ae0d1d3de`.

Batch throughput: unavailable without optimizer wall-time evidence. Available execution segments and runtime settings are retained in the JSON companion.

Separate deeper-analysis budget: none used by this review.

Next bounded experiment: fresh training confirmation; at most 2 failures and 3 positions per game; proposed new-game cap 8, analysis cap 361 transitions / 30 seconds per position. Freeze the experiment policy before dispatch. No new games scheduled.

Automatic categories, clock pressure and game-phase explanations are hypotheses; best strategic moves remain unknown.

Source stage: `a5db3ed943c40400f5c6d848a8e4e508f1e1fcf459b0231d2e4060916a371c41`; evidence: `27324b39c63d7e2e0515b169f5bf48af9e2546ecf28cb1898c35ad1bfc739ac8`. AI-written OpenAI Codex review; original entry/source provenance retained
